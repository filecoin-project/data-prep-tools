# Filecoin Data Preparation Tools

A python package with modular tools used in preparing data to make [filecoin](https://filecoin.io) storage deals.

## Installation

Install using pip.

```
pip install dataprep-tools
```
